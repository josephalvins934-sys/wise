<script>
    window.location = 'login'
</script>